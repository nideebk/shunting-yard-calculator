﻿namespace $safeprojectname$
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NineButton = new System.Windows.Forms.Button();
            this.EightButton = new System.Windows.Forms.Button();
            this.SevenButton = new System.Windows.Forms.Button();
            this.SixButton = new System.Windows.Forms.Button();
            this.FiveButton = new System.Windows.Forms.Button();
            this.LeftParenthesisButton = new System.Windows.Forms.Button();
            this.FourButton = new System.Windows.Forms.Button();
            this.RightParenthesisButton = new System.Windows.Forms.Button();
            this.ThreeButton = new System.Windows.Forms.Button();
            this.TwoButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.MinusButton = new System.Windows.Forms.Button();
            this.MultiplyButton = new System.Windows.Forms.Button();
            this.OneButton = new System.Windows.Forms.Button();
            this.MRButton = new System.Windows.Forms.Button();
            this.MSButton = new System.Windows.Forms.Button();
            this.MMinusButton = new System.Windows.Forms.Button();
            this.MCButton = new System.Windows.Forms.Button();
            this.MPlusButton = new System.Windows.Forms.Button();
            this.SquareRootButton = new System.Windows.Forms.Button();
            this.EqualsButton = new System.Windows.Forms.Button();
            this.ZeroButton = new System.Windows.Forms.Button();
            this.OverOneButton = new System.Windows.Forms.Button();
            this.PlusButton = new System.Windows.Forms.Button();
            this.PercentButton = new System.Windows.Forms.Button();
            this.TextBox = new System.Windows.Forms.RichTextBox();
            this.DivideButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.DotButton = new System.Windows.Forms.Button();
            this.ErrorBox = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // NineButton
            // 
            this.NineButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NineButton.AutoSize = true;
            this.NineButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NineButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.NineButton.FlatAppearance.BorderSize = 0;
            this.NineButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NineButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NineButton.Location = new System.Drawing.Point(180, 272);
            this.NineButton.Margin = new System.Windows.Forms.Padding(0);
            this.NineButton.Name = "NineButton";
            this.NineButton.Size = new System.Drawing.Size(90, 68);
            this.NineButton.TabIndex = 9;
            this.NineButton.Text = "9";
            this.NineButton.UseVisualStyleBackColor = false;
            this.NineButton.Click += new System.EventHandler(this.NineButton_Click);
            // 
            // EightButton
            // 
            this.EightButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EightButton.AutoSize = true;
            this.EightButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.EightButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.EightButton.FlatAppearance.BorderSize = 0;
            this.EightButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EightButton.Location = new System.Drawing.Point(90, 272);
            this.EightButton.Margin = new System.Windows.Forms.Padding(0);
            this.EightButton.Name = "EightButton";
            this.EightButton.Size = new System.Drawing.Size(90, 68);
            this.EightButton.TabIndex = 8;
            this.EightButton.Text = "8";
            this.EightButton.UseVisualStyleBackColor = false;
            this.EightButton.Click += new System.EventHandler(this.EightButton_Click);
            // 
            // SevenButton
            // 
            this.SevenButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SevenButton.AutoSize = true;
            this.SevenButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SevenButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.SevenButton.FlatAppearance.BorderSize = 0;
            this.SevenButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SevenButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SevenButton.Location = new System.Drawing.Point(0, 272);
            this.SevenButton.Margin = new System.Windows.Forms.Padding(0);
            this.SevenButton.Name = "SevenButton";
            this.SevenButton.Size = new System.Drawing.Size(90, 68);
            this.SevenButton.TabIndex = 7;
            this.SevenButton.Text = "7";
            this.SevenButton.UseVisualStyleBackColor = false;
            this.SevenButton.Click += new System.EventHandler(this.SevenButton_Click);
            // 
            // SixButton
            // 
            this.SixButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SixButton.AutoSize = true;
            this.SixButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SixButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.SixButton.FlatAppearance.BorderSize = 0;
            this.SixButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SixButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SixButton.Location = new System.Drawing.Point(180, 204);
            this.SixButton.Margin = new System.Windows.Forms.Padding(0);
            this.SixButton.Name = "SixButton";
            this.SixButton.Size = new System.Drawing.Size(90, 68);
            this.SixButton.TabIndex = 6;
            this.SixButton.Text = "6";
            this.SixButton.UseVisualStyleBackColor = false;
            this.SixButton.Click += new System.EventHandler(this.SixButton_Click);
            // 
            // FiveButton
            // 
            this.FiveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FiveButton.AutoSize = true;
            this.FiveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FiveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.FiveButton.FlatAppearance.BorderSize = 0;
            this.FiveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FiveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FiveButton.Location = new System.Drawing.Point(90, 204);
            this.FiveButton.Margin = new System.Windows.Forms.Padding(0);
            this.FiveButton.Name = "FiveButton";
            this.FiveButton.Size = new System.Drawing.Size(90, 68);
            this.FiveButton.TabIndex = 5;
            this.FiveButton.Text = "5";
            this.FiveButton.UseVisualStyleBackColor = false;
            this.FiveButton.Click += new System.EventHandler(this.FiveButton_Click);
            // 
            // LeftParenthesisButton
            // 
            this.LeftParenthesisButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LeftParenthesisButton.AutoSize = true;
            this.LeftParenthesisButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LeftParenthesisButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.LeftParenthesisButton.FlatAppearance.BorderSize = 0;
            this.LeftParenthesisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LeftParenthesisButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeftParenthesisButton.Location = new System.Drawing.Point(360, 136);
            this.LeftParenthesisButton.Margin = new System.Windows.Forms.Padding(0);
            this.LeftParenthesisButton.Name = "LeftParenthesisButton";
            this.LeftParenthesisButton.Size = new System.Drawing.Size(90, 68);
            this.LeftParenthesisButton.TabIndex = 14;
            this.LeftParenthesisButton.Text = "(";
            this.LeftParenthesisButton.UseVisualStyleBackColor = false;
            this.LeftParenthesisButton.Click += new System.EventHandler(this.LeftParenthesisButton_Click);
            // 
            // FourButton
            // 
            this.FourButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FourButton.AutoSize = true;
            this.FourButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FourButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.FourButton.FlatAppearance.BorderSize = 0;
            this.FourButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FourButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FourButton.Location = new System.Drawing.Point(0, 204);
            this.FourButton.Margin = new System.Windows.Forms.Padding(0);
            this.FourButton.Name = "FourButton";
            this.FourButton.Size = new System.Drawing.Size(90, 68);
            this.FourButton.TabIndex = 4;
            this.FourButton.Text = "4";
            this.FourButton.UseVisualStyleBackColor = false;
            this.FourButton.Click += new System.EventHandler(this.FourButton_Click);
            // 
            // RightParenthesisButton
            // 
            this.RightParenthesisButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RightParenthesisButton.AutoSize = true;
            this.RightParenthesisButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.RightParenthesisButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.RightParenthesisButton.FlatAppearance.BorderSize = 0;
            this.RightParenthesisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RightParenthesisButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RightParenthesisButton.Location = new System.Drawing.Point(360, 204);
            this.RightParenthesisButton.Margin = new System.Windows.Forms.Padding(0);
            this.RightParenthesisButton.Name = "RightParenthesisButton";
            this.RightParenthesisButton.Size = new System.Drawing.Size(90, 68);
            this.RightParenthesisButton.TabIndex = 15;
            this.RightParenthesisButton.Text = ")";
            this.RightParenthesisButton.UseVisualStyleBackColor = false;
            this.RightParenthesisButton.Click += new System.EventHandler(this.RightParenthesisButton_Click);
            // 
            // ThreeButton
            // 
            this.ThreeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ThreeButton.AutoSize = true;
            this.ThreeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ThreeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ThreeButton.FlatAppearance.BorderSize = 0;
            this.ThreeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ThreeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThreeButton.Location = new System.Drawing.Point(180, 136);
            this.ThreeButton.Margin = new System.Windows.Forms.Padding(0);
            this.ThreeButton.Name = "ThreeButton";
            this.ThreeButton.Size = new System.Drawing.Size(90, 68);
            this.ThreeButton.TabIndex = 3;
            this.ThreeButton.Text = "3";
            this.ThreeButton.UseVisualStyleBackColor = false;
            this.ThreeButton.Click += new System.EventHandler(this.ThreeButton_Click);
            // 
            // TwoButton
            // 
            this.TwoButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TwoButton.AutoSize = true;
            this.TwoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TwoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TwoButton.FlatAppearance.BorderSize = 0;
            this.TwoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TwoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TwoButton.Location = new System.Drawing.Point(90, 136);
            this.TwoButton.Margin = new System.Windows.Forms.Padding(0);
            this.TwoButton.Name = "TwoButton";
            this.TwoButton.Size = new System.Drawing.Size(90, 68);
            this.TwoButton.TabIndex = 2;
            this.TwoButton.Text = "2";
            this.TwoButton.UseVisualStyleBackColor = false;
            this.TwoButton.Click += new System.EventHandler(this.TwoButton_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tableLayoutPanel1.CausesValidation = false;
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Controls.Add(this.MinusButton, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.MultiplyButton, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.OneButton, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.TwoButton, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.FiveButton, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.EightButton, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.ThreeButton, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.SixButton, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.NineButton, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.SevenButton, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.FourButton, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.MRButton, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.MSButton, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.MMinusButton, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.MCButton, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.MPlusButton, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.SquareRootButton, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.EqualsButton, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.ZeroButton, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.OverOneButton, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.PlusButton, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.PercentButton, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.TextBox, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.LeftParenthesisButton, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.RightParenthesisButton, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.DivideButton, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.ClearButton, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.DotButton, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.ErrorBox, 1, 6);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-2, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.38461F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.38461F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.38461F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.38461F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.38461F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.38461F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(545, 446);
            this.tableLayoutPanel1.TabIndex = 20;
            // 
            // MinusButton
            // 
            this.MinusButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MinusButton.AutoSize = true;
            this.MinusButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MinusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MinusButton.FlatAppearance.BorderSize = 0;
            this.MinusButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinusButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinusButton.Location = new System.Drawing.Point(450, 204);
            this.MinusButton.Margin = new System.Windows.Forms.Padding(0);
            this.MinusButton.Name = "MinusButton";
            this.MinusButton.Size = new System.Drawing.Size(95, 68);
            this.MinusButton.TabIndex = 11;
            this.MinusButton.Text = "-";
            this.MinusButton.UseVisualStyleBackColor = false;
            this.MinusButton.Click += new System.EventHandler(this.MinusButton_Click);
            // 
            // MultiplyButton
            // 
            this.MultiplyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MultiplyButton.AutoSize = true;
            this.MultiplyButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MultiplyButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MultiplyButton.FlatAppearance.BorderSize = 0;
            this.MultiplyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MultiplyButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MultiplyButton.Location = new System.Drawing.Point(450, 272);
            this.MultiplyButton.Margin = new System.Windows.Forms.Padding(0);
            this.MultiplyButton.Name = "MultiplyButton";
            this.MultiplyButton.Size = new System.Drawing.Size(95, 68);
            this.MultiplyButton.TabIndex = 12;
            this.MultiplyButton.Text = "*";
            this.MultiplyButton.UseVisualStyleBackColor = false;
            this.MultiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
            // 
            // OneButton
            // 
            this.OneButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OneButton.AutoSize = true;
            this.OneButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.OneButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.OneButton.FlatAppearance.BorderSize = 0;
            this.OneButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OneButton.Location = new System.Drawing.Point(0, 136);
            this.OneButton.Margin = new System.Windows.Forms.Padding(0);
            this.OneButton.Name = "OneButton";
            this.OneButton.Size = new System.Drawing.Size(90, 68);
            this.OneButton.TabIndex = 1;
            this.OneButton.Text = "1";
            this.OneButton.UseVisualStyleBackColor = false;
            this.OneButton.Click += new System.EventHandler(this.OneButton_Click);
            // 
            // MRButton
            // 
            this.MRButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MRButton.AutoSize = true;
            this.MRButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MRButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MRButton.FlatAppearance.BorderSize = 0;
            this.MRButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MRButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MRButton.Location = new System.Drawing.Point(0, 68);
            this.MRButton.Margin = new System.Windows.Forms.Padding(0);
            this.MRButton.Name = "MRButton";
            this.MRButton.Size = new System.Drawing.Size(90, 68);
            this.MRButton.TabIndex = 21;
            this.MRButton.Text = "MR";
            this.MRButton.UseVisualStyleBackColor = false;
            this.MRButton.Click += new System.EventHandler(this.MRButton_Click);
            // 
            // MSButton
            // 
            this.MSButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MSButton.AutoSize = true;
            this.MSButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MSButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MSButton.FlatAppearance.BorderSize = 0;
            this.MSButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MSButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MSButton.Location = new System.Drawing.Point(90, 68);
            this.MSButton.Margin = new System.Windows.Forms.Padding(0);
            this.MSButton.Name = "MSButton";
            this.MSButton.Size = new System.Drawing.Size(90, 68);
            this.MSButton.TabIndex = 24;
            this.MSButton.Text = "MS";
            this.MSButton.UseVisualStyleBackColor = false;
            this.MSButton.Click += new System.EventHandler(this.MSButton_Click);
            // 
            // MMinusButton
            // 
            this.MMinusButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MMinusButton.AutoSize = true;
            this.MMinusButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MMinusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MMinusButton.FlatAppearance.BorderSize = 0;
            this.MMinusButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MMinusButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MMinusButton.Location = new System.Drawing.Point(360, 68);
            this.MMinusButton.Margin = new System.Windows.Forms.Padding(0);
            this.MMinusButton.Name = "MMinusButton";
            this.MMinusButton.Size = new System.Drawing.Size(90, 68);
            this.MMinusButton.TabIndex = 22;
            this.MMinusButton.Text = "M-";
            this.MMinusButton.UseVisualStyleBackColor = false;
            this.MMinusButton.Click += new System.EventHandler(this.MMinusButton_Click);
            // 
            // MCButton
            // 
            this.MCButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MCButton.AutoSize = true;
            this.MCButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MCButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MCButton.FlatAppearance.BorderSize = 0;
            this.MCButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MCButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MCButton.Location = new System.Drawing.Point(180, 68);
            this.MCButton.Margin = new System.Windows.Forms.Padding(0);
            this.MCButton.Name = "MCButton";
            this.MCButton.Size = new System.Drawing.Size(90, 68);
            this.MCButton.TabIndex = 25;
            this.MCButton.Text = "MC";
            this.MCButton.UseVisualStyleBackColor = false;
            this.MCButton.Click += new System.EventHandler(this.MCButton_Click);
            // 
            // MPlusButton
            // 
            this.MPlusButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MPlusButton.AutoSize = true;
            this.MPlusButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MPlusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MPlusButton.FlatAppearance.BorderSize = 0;
            this.MPlusButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MPlusButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MPlusButton.Location = new System.Drawing.Point(450, 68);
            this.MPlusButton.Margin = new System.Windows.Forms.Padding(0);
            this.MPlusButton.Name = "MPlusButton";
            this.MPlusButton.Size = new System.Drawing.Size(95, 68);
            this.MPlusButton.TabIndex = 23;
            this.MPlusButton.Text = "M+";
            this.MPlusButton.UseVisualStyleBackColor = false;
            this.MPlusButton.Click += new System.EventHandler(this.MPlusButton_Click);
            // 
            // SquareRootButton
            // 
            this.SquareRootButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SquareRootButton.AutoSize = true;
            this.SquareRootButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SquareRootButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.SquareRootButton.FlatAppearance.BorderSize = 0;
            this.SquareRootButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SquareRootButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SquareRootButton.Location = new System.Drawing.Point(270, 68);
            this.SquareRootButton.Margin = new System.Windows.Forms.Padding(0);
            this.SquareRootButton.Name = "SquareRootButton";
            this.SquareRootButton.Size = new System.Drawing.Size(90, 68);
            this.SquareRootButton.TabIndex = 26;
            this.SquareRootButton.Text = "√ ";
            this.SquareRootButton.UseVisualStyleBackColor = false;
            this.SquareRootButton.Click += new System.EventHandler(this.SquareRootButton_Click);
            // 
            // EqualsButton
            // 
            this.EqualsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EqualsButton.AutoSize = true;
            this.EqualsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.EqualsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tableLayoutPanel1.SetColumnSpan(this.EqualsButton, 4);
            this.EqualsButton.FlatAppearance.BorderSize = 0;
            this.EqualsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EqualsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EqualsButton.Location = new System.Drawing.Point(0, 340);
            this.EqualsButton.Margin = new System.Windows.Forms.Padding(0);
            this.EqualsButton.Name = "EqualsButton";
            this.EqualsButton.Size = new System.Drawing.Size(360, 68);
            this.EqualsButton.TabIndex = 16;
            this.EqualsButton.Text = "=";
            this.EqualsButton.UseVisualStyleBackColor = false;
            this.EqualsButton.Click += new System.EventHandler(this.EqualsButton_Click);
            // 
            // ZeroButton
            // 
            this.ZeroButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ZeroButton.AutoSize = true;
            this.ZeroButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ZeroButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ZeroButton.FlatAppearance.BorderSize = 0;
            this.ZeroButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ZeroButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ZeroButton.Location = new System.Drawing.Point(270, 272);
            this.ZeroButton.Margin = new System.Windows.Forms.Padding(0);
            this.ZeroButton.Name = "ZeroButton";
            this.ZeroButton.Size = new System.Drawing.Size(90, 68);
            this.ZeroButton.TabIndex = 18;
            this.ZeroButton.Text = "0";
            this.ZeroButton.UseVisualStyleBackColor = false;
            this.ZeroButton.Click += new System.EventHandler(this.ZeroButton_Click);
            // 
            // OverOneButton
            // 
            this.OverOneButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OverOneButton.AutoSize = true;
            this.OverOneButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.OverOneButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.OverOneButton.FlatAppearance.BorderSize = 0;
            this.OverOneButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OverOneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OverOneButton.Location = new System.Drawing.Point(270, 204);
            this.OverOneButton.Margin = new System.Windows.Forms.Padding(0);
            this.OverOneButton.Name = "OverOneButton";
            this.OverOneButton.Size = new System.Drawing.Size(90, 68);
            this.OverOneButton.TabIndex = 28;
            this.OverOneButton.Text = "1/x";
            this.OverOneButton.UseVisualStyleBackColor = false;
            this.OverOneButton.Click += new System.EventHandler(this.OverOneButton_Click);
            // 
            // PlusButton
            // 
            this.PlusButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PlusButton.AutoSize = true;
            this.PlusButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PlusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PlusButton.FlatAppearance.BorderSize = 0;
            this.PlusButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PlusButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlusButton.Location = new System.Drawing.Point(450, 136);
            this.PlusButton.Margin = new System.Windows.Forms.Padding(0);
            this.PlusButton.Name = "PlusButton";
            this.PlusButton.Size = new System.Drawing.Size(95, 68);
            this.PlusButton.TabIndex = 10;
            this.PlusButton.Text = "+";
            this.PlusButton.UseVisualStyleBackColor = false;
            this.PlusButton.Click += new System.EventHandler(this.PlusButton_Click);
            // 
            // PercentButton
            // 
            this.PercentButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PercentButton.AutoSize = true;
            this.PercentButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PercentButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PercentButton.FlatAppearance.BorderSize = 0;
            this.PercentButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PercentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PercentButton.Location = new System.Drawing.Point(270, 136);
            this.PercentButton.Margin = new System.Windows.Forms.Padding(0);
            this.PercentButton.Name = "PercentButton";
            this.PercentButton.Size = new System.Drawing.Size(90, 68);
            this.PercentButton.TabIndex = 27;
            this.PercentButton.Text = "%";
            this.PercentButton.UseVisualStyleBackColor = false;
            this.PercentButton.Click += new System.EventHandler(this.PercentButton_Click);
            // 
            // TextBox
            // 
            this.TextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBox.BackColor = System.Drawing.Color.White;
            this.TextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.TextBox, 6);
            this.TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox.Location = new System.Drawing.Point(0, 0);
            this.TextBox.Margin = new System.Windows.Forms.Padding(0);
            this.TextBox.Multiline = false;
            this.TextBox.Name = "TextBox";
            this.TextBox.ReadOnly = true;
            this.TextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.TextBox.Size = new System.Drawing.Size(545, 68);
            this.TextBox.TabIndex = 20;
            this.TextBox.Text = "";
            this.TextBox.TextChanged += new System.EventHandler(this.TextBox_TextChanged);
            // 
            // DivideButton
            // 
            this.DivideButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DivideButton.AutoSize = true;
            this.DivideButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DivideButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.DivideButton.FlatAppearance.BorderSize = 0;
            this.DivideButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DivideButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DivideButton.Location = new System.Drawing.Point(450, 340);
            this.DivideButton.Margin = new System.Windows.Forms.Padding(0);
            this.DivideButton.Name = "DivideButton";
            this.DivideButton.Size = new System.Drawing.Size(95, 68);
            this.DivideButton.TabIndex = 13;
            this.DivideButton.Text = "/";
            this.DivideButton.UseVisualStyleBackColor = false;
            this.DivideButton.Click += new System.EventHandler(this.DivideButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ClearButton.AutoSize = true;
            this.ClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClearButton.FlatAppearance.BorderSize = 0;
            this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(360, 272);
            this.ClearButton.Margin = new System.Windows.Forms.Padding(0);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(90, 68);
            this.ClearButton.TabIndex = 19;
            this.ClearButton.Text = "C";
            this.ClearButton.UseVisualStyleBackColor = false;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // DotButton
            // 
            this.DotButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DotButton.AutoSize = true;
            this.DotButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DotButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.DotButton.FlatAppearance.BorderSize = 0;
            this.DotButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DotButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DotButton.Location = new System.Drawing.Point(360, 340);
            this.DotButton.Margin = new System.Windows.Forms.Padding(0);
            this.DotButton.Name = "DotButton";
            this.DotButton.Size = new System.Drawing.Size(90, 68);
            this.DotButton.TabIndex = 17;
            this.DotButton.Text = ".";
            this.DotButton.UseVisualStyleBackColor = false;
            this.DotButton.Click += new System.EventHandler(this.DotButton_Click);
            // 
            // ErrorBox
            // 
            this.ErrorBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.ErrorBox, 6);
            this.ErrorBox.ForeColor = System.Drawing.Color.Red;
            this.ErrorBox.Location = new System.Drawing.Point(0, 408);
            this.ErrorBox.Margin = new System.Windows.Forms.Padding(0);
            this.ErrorBox.Name = "ErrorBox";
            this.ErrorBox.ReadOnly = true;
            this.ErrorBox.Size = new System.Drawing.Size(545, 38);
            this.ErrorBox.TabIndex = 29;
            this.ErrorBox.Text = "";
            this.ErrorBox.TextChanged += new System.EventHandler(this.ErrorBox_TextChanged_1);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(541, 444);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(555, 481);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Resize += new System.EventHandler(this.Calculator_Resize);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button NineButton;
        private System.Windows.Forms.Button EightButton;
        private System.Windows.Forms.Button SevenButton;
        private System.Windows.Forms.Button SixButton;
        private System.Windows.Forms.Button FiveButton;
        private System.Windows.Forms.Button LeftParenthesisButton;
        private System.Windows.Forms.Button FourButton;
        private System.Windows.Forms.Button RightParenthesisButton;
        private System.Windows.Forms.Button ThreeButton;
        private System.Windows.Forms.Button TwoButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button ZeroButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button EqualsButton;
        private System.Windows.Forms.Button MSButton;
        private System.Windows.Forms.Button MMinusButton;
        private System.Windows.Forms.Button MCButton;
        private System.Windows.Forms.Button SquareRootButton;
        private System.Windows.Forms.Button PercentButton;
        private System.Windows.Forms.Button OverOneButton;
        private System.Windows.Forms.Button MinusButton;
        private System.Windows.Forms.Button MultiplyButton;
        private System.Windows.Forms.Button OneButton;
        private System.Windows.Forms.Button MRButton;
        private System.Windows.Forms.Button MPlusButton;
        private System.Windows.Forms.Button PlusButton;
        private System.Windows.Forms.RichTextBox TextBox;
        private System.Windows.Forms.Button DivideButton;
        private System.Windows.Forms.Button DotButton;
        private System.Windows.Forms.RichTextBox ErrorBox;
    }
}

