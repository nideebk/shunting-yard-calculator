﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public enum AllowedNext
    {
        AllowOperatorNext = 1,
        AllowOperandNext = 2,
        AllowLeftParethesisNext = 4,
        AllowRightParenthesisNext = 8,
        AllowInvalidNext = 16,
        AllowMemRecNext = 32
    }

    public partial class Calculator : Form
    {
        private const int MAX_ARRAY = 100;

        private int allowable = (int)(AllowedNext.AllowOperandNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowOperatorNext | AllowedNext.AllowMemRecNext);
        private int resetAllowable = (int)(AllowedNext.AllowOperandNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowOperatorNext | AllowedNext.AllowMemRecNext);

        private Memory memory = new Memory();
        private IExpressionElement[] expression = new IExpressionElement[MAX_ARRAY];

        private int exprIndex = 0;

        AllowedNext currentAction = AllowedNext.AllowInvalidNext;

        private bool clickAbility = true;
        private bool equalBlock = true;


        private bool ValidateValue(AllowedNext calcaction)
        {
            if ((allowable & (int)calcaction) != 0)
                return true;
            else
                return false;
        }

        private void EqualsReset()
        {
            Array.Clear(expression, 0, 100);
            exprIndex = 0;
            expression[exprIndex] = new Operand(TextBox.Text);
            allowable = (int)(AllowedNext.AllowOperatorNext | AllowedNext.AllowLeftParethesisNext);
            currentAction = AllowedNext.AllowOperandNext;
        }

        private void HandleCalculatorEvent(AllowedNext calcAction, string name)
        {
            if (ValidateValue(calcAction))
            {
                if ((TextBox.Text.Length + name.Length) > (TextBox.Size.Width / 18.5))
                {
                    ErrorBox.Text = "Over Character Limit";
                    return;
                }

                equalBlock = false;

                if (currentAction == AllowedNext.AllowInvalidNext)
                {
                    if (calcAction == AllowedNext.AllowLeftParethesisNext)
                    {
                        expression[exprIndex] = new LeftParaOperator();
                        TextBox.Text = (expression[exprIndex] as ILeftParaOperator).Display(TextBox.Text);
                        allowable = (expression[exprIndex] as ILeftParaOperator).GetAllowedValue();
                        currentAction = calcAction;
                    }
                    else if (name == MinusButton.Text)
                    {
                        expression[exprIndex] = new Operand(name);
                        TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                        allowable = (expression[exprIndex] as Operand).GetAllowedValue();
                        calcAction = AllowedNext.AllowOperandNext;
                        currentAction = calcAction;
                    }
                    else if (calcAction == AllowedNext.AllowOperandNext)
                    {
                        if (name == ".")
                        {
                            expression[exprIndex] = new Operand("0");
                            TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                            (expression[exprIndex] as IOperand).StoreValue(name);
                        }
                        else
                            expression[exprIndex] = new Operand(name);
                        TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                        allowable = (expression[exprIndex] as Operand).GetAllowedValue();
                        currentAction = calcAction;
                    }
                    else if (calcAction == AllowedNext.AllowMemRecNext)
                    {
                        expression[exprIndex] = new Operand(name);
                        TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                        allowable = (int)(AllowedNext.AllowOperatorNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowRightParenthesisNext);
                        currentAction = calcAction;
                    }
                }
                else if (calcAction == AllowedNext.AllowOperatorNext)
                {
                    if ((expression[exprIndex].GetType() == typeof(LeftParaOperator)) && (name == "-"))
                    {
                        expression[++exprIndex] = new Operand(name);
                        TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                        allowable = (expression[exprIndex] as IOperand).GetAllowedValue();
                        calcAction = AllowedNext.AllowOperandNext;
                        currentAction = calcAction;
                    }
                    else if (((expression[exprIndex].GetType() != typeof(Operand)) && (expression[exprIndex].GetType() != typeof(LeftParaOperator)) || ((expression[exprIndex].GetType() == typeof(Operand)) && (expression[exprIndex] as Operand).GetValue() != "-")))
                    {
                        expression[++exprIndex] = new Operator(name);
                        TextBox.Text = (expression[exprIndex] as IOperator).Display(TextBox.Text);
                        allowable = (expression[exprIndex] as IOperator).GetAllowedValue();
                        currentAction = calcAction;
                    }
                }
                else if (calcAction == AllowedNext.AllowLeftParethesisNext)
                {
                    if ((exprIndex == 0) && (expression[exprIndex].GetType() == typeof(Operand)) && ((expression[exprIndex] as IOperand).GetValue() == "-"))
                    {
                        (expression[exprIndex] as IOperand).StoreValue("1");
                        expression[++exprIndex] = new Operator("*");
                    }
                    else if ((expression[exprIndex].GetType() == typeof(RightParaOperator) || (expression[exprIndex].GetType() == typeof(Operand))))
                        expression[++exprIndex] = new Operator("*");
                    expression[++exprIndex] = new LeftParaOperator();
                    TextBox.Text = (expression[exprIndex] as ILeftParaOperator).Display(TextBox.Text);
                    allowable = (expression[exprIndex] as LeftParaOperator).GetAllowedValue();
                    currentAction = calcAction;
                }
                else if (calcAction == AllowedNext.AllowRightParenthesisNext)
                {
                    expression[++exprIndex] = new RightParaOperator();
                    TextBox.Text = (expression[exprIndex] as IRightParaOperator).Display(TextBox.Text);
                    allowable = (expression[exprIndex] as RightParaOperator).GetAllowedValue();
                    currentAction = calcAction;
                }
                else if (currentAction == calcAction)
                {
                    (expression[exprIndex] as IOperand).StoreValue(name);
                    TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                    allowable = (expression[exprIndex] as Operand).GetAllowedValue();
                    currentAction = calcAction;
                }
                else
                {
                    if ((expression[exprIndex].GetType() == typeof(RightParaOperator) || (expression[exprIndex].GetType() == typeof(Operand))))
                        expression[++exprIndex] = new Operator("*");
                    if (calcAction == AllowedNext.AllowOperandNext)
                    {
                        if (name == ".")
                        {
                            expression[++exprIndex] = new Operand("0");
                            TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                            (expression[exprIndex] as IOperand).StoreValue(name);
                        }
                        else
                            expression[++exprIndex] = new Operand(name);
                        TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                        allowable = (expression[exprIndex] as Operand).GetAllowedValue();
                        currentAction = calcAction;
                    }
                    else if (calcAction == AllowedNext.AllowMemRecNext)
                    {
                        expression[++exprIndex] = new Operand(name);
                        TextBox.Text = (expression[exprIndex] as IOperand).Display(TextBox.Text);
                        allowable = (int)(AllowedNext.AllowOperatorNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowRightParenthesisNext);
                        currentAction = calcAction;
                    }
                }
            }
            else
            {
                return;
            }
        }

        private List<IExpressionElement> ToPostfix()
        {
            var operStack = new Stack<IExpressionElement>();
            var output = new List<IExpressionElement>();
            exprIndex = 0;

            while (expression[exprIndex] != null)
            {
                if (expression[exprIndex].GetType() == typeof(Operand))
                    output.Add(expression[exprIndex]);
                else if (expression[exprIndex].GetType() == typeof(Operator))
                {
                    while ((operStack.Count() != 0) && (operStack.Peek().GetType() == typeof(Operator)) && ((operStack.Peek() as IOperator).GetPrecedence() >= (expression[exprIndex] as Operator).GetPrecedence()))
                        output.Add(operStack.Pop());
                    operStack.Push(expression[exprIndex]);
                }
                else if (expression[exprIndex].GetType() == typeof(LeftParaOperator))
                    operStack.Push(expression[exprIndex]);
                else if (expression[exprIndex].GetType() == typeof(RightParaOperator))
                {
                    while (operStack.Peek().GetType() != typeof(LeftParaOperator))
                        output.Add(operStack.Pop());
                    operStack.Pop();
                }

                exprIndex++;
            }

            if (operStack.Count() > 0)
                output.Add(operStack.Pop());

            return output;
        }

        private string Solve()
        {
            try
            {
                List<IExpressionElement> postFix = ToPostfix();
                var numStack = new Stack<double>();
                double a, b;


                foreach (IExpressionElement counter in postFix)
                {
                    if (counter.GetType() == typeof(Operand))
                    {
                        numStack.Push(Convert.ToDouble((counter as IOperand).GetValue()));
                    }
                    else if ((counter as IOperator).GetOper() == "+")
                    {
                        a = Convert.ToDouble(numStack.Pop());
                        b = Convert.ToDouble(numStack.Pop());
                        numStack.Push(a + b);
                    }
                    else if ((counter as Operator).GetOper() == "-")
                    {
                        a = Convert.ToDouble(numStack.Pop());
                        b = Convert.ToDouble(numStack.Pop());
                        numStack.Push(b - a);
                    }
                    else if ((counter as Operator).GetOper() == "*")
                    {
                        a = Convert.ToDouble(numStack.Pop());
                        b = Convert.ToDouble(numStack.Pop());
                        numStack.Push(a * b);
                    }
                    else if ((counter as Operator).GetOper() == "/")
                    {
                        a = Convert.ToDouble(numStack.Pop());
                        b = Convert.ToDouble(numStack.Pop());
                        if (a == 0)
                        {
                            clickAbility = false;
                            return "Undefined";
                        }
                        numStack.Push(b / a);
                    }
                }

                exprIndex = 0;

                return numStack.Pop().ToString();
            }
            catch
            {
                clickAbility = false;
                ErrorBox.Text = "Invalid Input";
                return "Error";
            }
        }

        public Calculator()
        {
            InitializeComponent();
        }

        private void OneButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, OneButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }

        }

        private void TwoButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, TwoButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void ThreeButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, ThreeButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void FourButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, FourButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void FiveButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, FiveButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void SixButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, SixButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void SevenButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, SevenButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void EightButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, EightButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void NineButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, NineButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void PlusButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperatorNext, PlusButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void MinusButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperatorNext, MinusButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void MultiplyButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperatorNext, MultiplyButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void DivideButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperatorNext, DivideButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void LeftParenthesisButton_Click(object sender, EventArgs e)
        {

            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowLeftParethesisNext, LeftParenthesisButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void RightParenthesisButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowRightParenthesisNext, RightParenthesisButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void EqualsButton_Click(object sender, EventArgs e)
        {
            if ((clickAbility == true) && (equalBlock == false))
            {
                TextBox.Text = Solve();
                EqualsReset();
            }
        }

        private void DotButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, DotButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void ZeroButton_Click(object sender, EventArgs e)
        {
            if (clickAbility == true)
                HandleCalculatorEvent(AllowedNext.AllowOperandNext, ZeroButton.Text);
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length + 1) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            clickAbility = true;
            equalBlock = true;
            Array.Clear(expression, 0, 100);
            exprIndex = 0;
            allowable = resetAllowable;
            currentAction = AllowedNext.AllowInvalidNext;
            TextBox.Text = ErrorBox.Text = "";
        }

        private void TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void MRButton_Click(object sender, EventArgs e)
        {
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
            if ((clickAbility == true) && (ValidateValue(AllowedNext.AllowMemRecNext)))
                HandleCalculatorEvent(AllowedNext.AllowMemRecNext, memory.GetMemory().ToString());
        }

        private void MSButton_Click(object sender, EventArgs e)
        {
            if ((clickAbility == true) && (Solve() != "Error"))
                memory.StoreMemory(Convert.ToDouble(Solve()));
            else if ((TextBox.Text == "") || (TextBox.Text == "Error"))
            {
                TextBox.Text = "Error";
                ErrorBox.Text = "No Valid Input to Save";
            }
            else
            {
                TextBox.Text = "Error";
                ErrorBox.Text = "Unable to Save the Error Value";
            }
        }

        private void MCButton_Click(object sender, EventArgs e)
        {
            memory.ClearMemory();
        }

        private void MMinusButton_Click(object sender, EventArgs e)
        {
            memory.SubMemory();
        }

        private void MPlusButton_Click(object sender, EventArgs e)
        {
            memory.AddMemory();
        }

        private void PercentButton_Click(object sender, EventArgs e)
        {
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
            if ((clickAbility == true) && (Solve() != "Error"))
            {
                TextBox.Text = (Convert.ToDouble(Solve()) / 100).ToString();
                EqualsReset();
            }
            else
            {
                TextBox.Text = "Error";
                ErrorBox.Text = "No Valid Input to Perform Operation On";
            }
        }

        private void OverOneButton_Click(object sender, EventArgs e)
        {
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
            if ((clickAbility == true) && (Solve() != "Error"))
            {
                if (Solve() == "0")
                {
                    TextBox.Text = "Undefined";
                    clickAbility = false;
                }
                else
                    TextBox.Text = (1 / Convert.ToDouble(Solve())).ToString();
                EqualsReset();
            }
            else
            {
                TextBox.Text = "Error";
                ErrorBox.Text = "No Valid Input to Perform Operation On";
            }
        }

        private void SquareRootButton_Click(object sender, EventArgs e)
        {
            if ((ErrorBox.Text == "Over Character Limit") && ((TextBox.Text.Length) < (TextBox.Size.Width / 18.5)))
            {
                ErrorBox.Text = "";
            }
            if ((clickAbility == true) && (Solve() != "Error") && (Convert.ToDouble(Solve()) >= 0))
            {
                TextBox.Text = Math.Sqrt(Convert.ToDouble(Solve())).ToString();
                EqualsReset();
            }
            else
            {
                TextBox.Text = "Error";
                ErrorBox.Text = "No Valid Input to Perform Operation On";
            }
        }

        private void ErrorBox_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Calculator_Resize(object sender, EventArgs e)
        {
            if ((TextBox.Text.Length) > (TextBox.Size.Width / 18.5))
                ErrorBox.Text = "Over Character Limit";
            else if ((TextBox.Text.Length) < (TextBox.Size.Width / 18.5))
                ErrorBox.Text = "";
        }
    }
}
