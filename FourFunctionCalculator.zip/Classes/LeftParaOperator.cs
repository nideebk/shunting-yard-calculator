﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class LeftParaOperator : ILeftParaOperator
    {
        private int allowedValue = (int)(AllowedNext.AllowOperandNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowOperatorNext | AllowedNext.AllowMemRecNext);
        private char paraEle = '(';


        public string GetPara()
        {
            return paraEle.ToString();
        }

        public string Display(string textBox)
        {
            return textBox += paraEle;
        }

        public int GetAllowedValue()
        {
            return allowedValue;
        }
    }
}
