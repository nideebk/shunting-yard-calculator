﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Memory : IMemory
    {
        private double mem = 0;

        public double GetMemory()
        {
            return mem;
        }

        public void StoreMemory(double memory)
        {
            mem = memory;
        }

        public void AddMemory()
        {
            mem++;
        }

        public void SubMemory()
        {
            mem--;
        }

        public void ClearMemory()
        {
            mem = 0;
        }
    }
}
