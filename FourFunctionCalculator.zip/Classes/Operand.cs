﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Operand : IOperand
    {
        private string value;
        private string digit;
        private bool doubleState = false;
        private int allowedValue = (int)(AllowedNext.AllowOperandNext | AllowedNext.AllowOperatorNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowRightParenthesisNext);


        public Operand(string val)
        {
            value = digit = val;
        }

        public void StoreValue(string Name)
        {
            if ((doubleState == false) || (Name != "."))
            {
                digit = Name;
                value += Name;
            }
        }

        public string GetValue()
        {
            return value;
        }

        public string Display(string textBox)
        {
            var stringRandom = "";

            if ((digit != ".") || (doubleState == false))
            {
                if (digit == ".")
                    doubleState = true;
                stringRandom = textBox + digit;
                digit = "";
                return stringRandom;
            }
            else
                return textBox;
        }

        public int GetAllowedValue()
        {
            return allowedValue;
        }
    }
}
