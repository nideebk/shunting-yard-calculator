﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Operator : IOperator
    {
        private string operation;
        private int allowedValue = (int)(AllowedNext.AllowOperandNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowMemRecNext);
        private int pre;


        public Operator(string name)
        {
            operation = name;
        }

        public string Display(string textBox)
        {
            return textBox += operation;
        }

        public string GetOper()
        {
            return operation;
        }

        public int GetAllowedValue()
        {
            return allowedValue;
        }

        public int GetPrecedence()
        {
            return pre;
        }

        public void Precedence()
        {
            if ((operation == "+") || (operation == "-"))
                pre = 1;
            else if ((operation == "*") || (operation == "/"))
                pre = 2;
            else
                pre = 0;
        }
    }
}
