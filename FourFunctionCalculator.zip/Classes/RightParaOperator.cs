﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class RightParaOperator : IRightParaOperator
    {
        private int allowedValue = (int)(AllowedNext.AllowOperatorNext | AllowedNext.AllowLeftParethesisNext | AllowedNext.AllowRightParenthesisNext | AllowedNext.AllowOperandNext | AllowedNext.AllowMemRecNext);
        private char paraEle = ')';


        public string GetPara()
        {
            return paraEle.ToString();
        }

        public string Display(string textBox)
        {
            return textBox += paraEle;
        }

        public int GetAllowedValue()
        {
            return allowedValue;
        }
    }
}
