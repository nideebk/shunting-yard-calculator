﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    interface IMemory
    {
        void StoreMemory(double mem);

        double GetMemory();

        void AddMemory();

        void SubMemory();

        void ClearMemory();
    }
}
