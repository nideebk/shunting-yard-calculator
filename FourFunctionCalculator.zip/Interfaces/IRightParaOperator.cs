﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    interface IRightParaOperator : IExpressionElement
    {
        string GetPara();

        new string Display(string textBox);

        new int GetAllowedValue();
    }
}
